# SHADOW STRIKE — Mobile Browser Prototype

A small playable 3D browser prototype for the futuristic city of Blackridge City.

## Files
- `index.html` — the game prototype. Open it in a browser with internet access.

## Controls
- Desktop: WASD to move, mouse drag to look, Space to jump.
- Mobile: left joystick to move, drag the right look area to turn; use Sprint, Jump, Crouch, Camera, and Interact buttons.

## Prototype status
This is a foundation prototype, not a finished commercial game. It has a simple city environment, placeholder player, beacon objective, movement, and camera toggle. It does not include mission progression, polished character animations, audio, save systems, multiplayer, or native mobile packaging.

The prototype loads Three.js from a CDN, so internet access is required when opening it.
